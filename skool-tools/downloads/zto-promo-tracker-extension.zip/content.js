// Small note on Skool group pages: last post here and when you can promote again.
// Reads only this extension's own saved tracker data. Never posts, clicks or reads anything on the page.
(() => {
  const KEY = "zto.tracker";
  const RESERVED = new Set(["", "discovery", "settings", "chat", "notifications", "signup", "login", "about", "pricing", "affiliates", "careers", "skool-games"]);
  const DAY = 86400000;
  let lastPath = "", box = null, hiddenFor = new Set();

  const slug = () => location.pathname.split("/").filter(Boolean)[0] || "";
  const daysAgo = (d) => Math.round((new Date(new Date().toDateString()) - new Date(d)) / DAY);

  function status(data, g) {
    const posts = data.posts.filter((p) => p.groupId === g.id).sort((a, b) => b.date.localeCompare(a.date));
    const promos = posts.filter((p) => p.kind === "promo");
    const last = promos[0];
    let label = "Ready to promote", tone = "#4caf7a";
    if (g.rule === "none") { label = "No self promotion here"; tone = "#e0664f"; }
    else if (g.rule === "pending") { label = "Membership pending"; tone = "#b3aa9f"; }
    else if (g.rule === "thread") { label = last ? "One per thread: is there a new thread?" : "Ready (one per thread)"; tone = last ? "#e8a33d" : "#4caf7a"; }
    else if (last) { const gap = daysAgo(last.date); const wait = (+g.every || 0) - gap; if (wait > 0) { label = `Wait ${wait} more day${wait === 1 ? "" : "s"} to promote`; tone = "#e8a33d"; } }
    const here = posts.find((p) => p.link && location.href.split("?")[0].startsWith(p.link.split("?")[0]));
    return { label, tone, last, any: posts[0], here };
  }

  function el(tag, css, text) { const e = document.createElement(tag); if (css) e.style.cssText = css; if (text) e.textContent = text; return e; }

  function draw(data) {
    const s = slug();
    if (box) { box.remove(); box = null; }
    if (RESERVED.has(s) || hiddenFor.has(s)) return;
    const g = data && data.groups.find((x) => x.slug === s);
    box = el("div", "position:fixed;right:16px;bottom:16px;z-index:2147483646;background:#241f1c;color:#f6f4f0;border:1px solid #3e3630;border-radius:12px;padding:10px 12px;font:13px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:280px;box-shadow:0 6px 24px rgba(0,0,0,.35)");
    const top = el("div", "display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:4px");
    top.append(el("strong", "font-size:12px;letter-spacing:.04em;color:#e8a33d", "PROMO TRACKER"));
    const x = el("button", "background:none;border:0;color:#b3aa9f;cursor:pointer;font-size:16px;line-height:1;padding:0", "×");
    x.title = "Hide on this group until you reload"; x.onclick = () => { hiddenFor.add(s); box.remove(); box = null; };
    top.append(x); box.append(top);
    if (!g) {
      box.append(el("div", "color:#b3aa9f", "This group isn't in your tracker yet."));
    } else {
      const st = status(data, g);
      const line = el("div", "display:flex;gap:6px;align-items:center;font-weight:600");
      line.append(el("span", `width:9px;height:9px;border-radius:50%;background:${st.tone};flex:none`), el("span", "", st.label));
      box.append(el("div", "font-weight:600;margin-bottom:2px", g.name), line);
      box.append(el("div", "color:#b3aa9f;margin-top:2px", st.last ? `Last promo: ${st.last.date} (${daysAgo(st.last.date)} days ago)` : "No promo logged here yet"));
      if (g.where) box.append(el("div", "color:#b3aa9f", `Where: ${g.where}`));
      if (st.here) box.append(el("div", "color:#e8a33d;margin-top:4px", `You posted on this page on ${st.here.date}. Check someone has replied since before you post again.`));
    }
    const btn = el("button", "margin-top:8px;background:#e8a33d;color:#1d1916;border:0;border-radius:8px;padding:6px 10px;font-weight:600;cursor:pointer;font-size:12px", g ? "Log a post on this page" : "Add this group");
    btn.onclick = () => chrome.runtime.sendMessage({ type: "zto-open", url: location.href.split("#")[0] });
    box.append(btn);
    document.documentElement.append(box);
  }

  function tick() {
    if (location.pathname === lastPath) return;
    lastPath = location.pathname;
    chrome.storage.local.get(KEY, (o) => draw(o[KEY] || { groups: [], posts: [] }));
  }
  chrome.storage.onChanged.addListener((c) => { if (c[KEY]) { lastPath = ""; tick(); } });
  setInterval(tick, 1500);
  tick();
})();
