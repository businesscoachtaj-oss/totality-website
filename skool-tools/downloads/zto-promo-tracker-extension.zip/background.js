// Opens the tracker in a tab: from the toolbar button, or from the note on a Skool page.
const open = (q) => chrome.tabs.create({ url: chrome.runtime.getURL("tracker.html" + (q || "")) });
chrome.action.onClicked.addListener(() => open(""));
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "zto-open" && typeof msg.url === "string" && msg.url.startsWith("https://www.skool.com/")) {
    open("?url=" + encodeURIComponent(msg.url));
  }
});
